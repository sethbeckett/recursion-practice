public class TreeInfo {
    public int width;
    public int height;

    public TreeInfo(int width, int height){
        this.width = width;
        this.height = height;
    }
}
